import { NextResponse } from "next/server";
import {
  FieldValue,
} from "firebase-admin/firestore";

import { adminDb } from "@/lib/firebase-admin";

interface OrderRequestItem {
  productId: string;
  quantity: number;
}

interface OrderRequestBody {
  customer: {
    name: string;
    email: string;
    phone: string;
  };

  delivery: {
    address: string;
    city: string;
    state: string;
    country: string;
    instructions: string;
  };

  items: OrderRequestItem[];
}

export async function POST(request: Request) {
  try {
    const body =
      (await request.json()) as OrderRequestBody;

    if (
      !body.customer ||
      !body.delivery ||
      !Array.isArray(body.items) ||
      body.items.length === 0
    ) {
      return NextResponse.json(
        {
          error: "Invalid order data.",
        },
        { status: 400 }
      );
    }

    /*
     * Basic customer validation
     */
    const customer = body.customer;

    if (
      !customer.name?.trim() ||
      !customer.email?.trim() ||
      !customer.phone?.trim()
    ) {
      return NextResponse.json(
        {
          error: "Customer information is incomplete.",
        },
        { status: 400 }
      );
    }

    /*
     * Basic delivery validation
     */
    const delivery = body.delivery;

    if (
      !delivery.address?.trim() ||
      !delivery.city?.trim() ||
      !delivery.state?.trim() ||
      !delivery.country?.trim()
    ) {
      return NextResponse.json(
        {
          error: "Delivery information is incomplete.",
        },
        { status: 400 }
      );
    }

    /*
     * Validate quantities before touching Firestore.
     */
    for (const item of body.items) {
      if (
        !item.productId ||
        !Number.isInteger(item.quantity) ||
        item.quantity <= 0
      ) {
        return NextResponse.json(
          {
            error: "Invalid product quantity.",
          },
          { status: 400 }
        );
      }
    }

    /*
     * Read products from Firestore.
     */
    const validatedItems = [];

    let subtotal = 0;

    for (const item of body.items) {
      const productRef = adminDb
        .collection("products")
        .doc(item.productId);

      const productSnapshot = await productRef.get();

      if (!productSnapshot.exists) {
        return NextResponse.json(
          {
            error: `Product ${item.productId} was not found.`,
          },
          { status: 400 }
        );
      }

      const product =
        productSnapshot.data();

      if (!product) {
        return NextResponse.json(
          {
            error: "Unable to read product.",
          },
          { status: 400 }
        );
      }

      /*
       * Product must be active.
       */
      if (product.isActive !== true) {
        return NextResponse.json(
          {
            error: `${product.name} is no longer available.`,
          },
          { status: 400 }
        );
      }

      /*
       * Validate price.
       */
      if (
        typeof product.price !== "number" ||
        product.price < 0
      ) {
        return NextResponse.json(
          {
            error: `Invalid price for ${product.name}.`,
          },
          { status: 400 }
        );
      }

      /*
       * Validate stock.
       */
      if (
        typeof product.stock !== "number" ||
        product.stock < item.quantity
      ) {
        return NextResponse.json(
          {
            error: `${product.name} does not have enough stock.`,
          },
          { status: 400 }
        );
      }

      const itemSubtotal =
        product.price * item.quantity;

      subtotal += itemSubtotal;

      validatedItems.push({
        productId: productSnapshot.id,
        name: product.name,
        slug: product.slug,
        price: product.price,
        quantity: item.quantity,
        subtotal: itemSubtotal,
      });
    }

    /*
     * Delivery is currently free.
     * We can implement real delivery calculation later.
     */
    const deliveryFee = 0;

    const total = subtotal + deliveryFee;

    /*
     * Currently all products use NGN.
     */
    const currency = "NGN";

    /*
     * Create the order using Admin SDK.
     *
     * Admin SDK bypasses Firestore client rules.
     */
    const orderRef = await adminDb
      .collection("orders")
      .add({
        userId: null,

        customer: {
          name: customer.name.trim(),
          email: customer.email.trim(),
          phone: customer.phone.trim(),
        },

        delivery: {
          address: delivery.address.trim(),
          city: delivery.city.trim(),
          state: delivery.state.trim(),
          country: delivery.country.trim(),
          instructions:
            delivery.instructions?.trim() || "",
        },

        items: validatedItems,

        subtotal,
        deliveryFee,
        total,
        currency,

        paymentStatus: "pending",
        paymentReference: "",

        orderStatus: "pending",

        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      });

    return NextResponse.json(
      {
        success: true,
        orderId: orderRef.id,
        subtotal,
        deliveryFee,
        total,
        currency,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error(
      "Failed to create order:",
      error
    );

    return NextResponse.json(
      {
        error: "Unable to create order.",
      },
      { status: 500 }
    );
  }
}