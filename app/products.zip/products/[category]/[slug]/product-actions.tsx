// app/products/[category]/[slug]/product-actions.tsx

"use client";

import { useState } from "react";

interface ProductActionsProps {
  stock: number;
  productName: string;
}

export default function ProductActions({
  stock,
}: ProductActionsProps) {
  const [quantity, setQuantity] = useState(1);

  const isOutOfStock = stock <= 0;

  const decreaseQuantity = () => {
    setQuantity((current) => Math.max(1, current - 1));
  };

  const increaseQuantity = () => {
    setQuantity((current) => Math.min(stock, current + 1));
  };

  return (
    <div className="product-actions">
      <div className="product-stock">
        {isOutOfStock ? (
          <span className="out-of-stock">Out of stock</span>
        ) : (
          <span>{stock} in stock</span>
        )}
      </div>

      <div className="product-quantity">
        <span>Quantity</span>

        <div className="quantity-control">
          <button
            type="button"
            onClick={decreaseQuantity}
            disabled={isOutOfStock || quantity <= 1}
            aria-label="Decrease quantity"
          >
            −
          </button>

          <span>{quantity}</span>

          <button
            type="button"
            onClick={increaseQuantity}
            disabled={isOutOfStock || quantity >= stock}
            aria-label="Increase quantity"
          >
            +
          </button>
        </div>
      </div>

      <button
        type="button"
        className="product-add-to-cart"
        disabled={isOutOfStock}
      >
        {isOutOfStock ? "Out of Stock" : "Add to Cart"}
      </button>
    </div>
  );
}