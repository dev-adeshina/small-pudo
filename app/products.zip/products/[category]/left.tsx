import Image from 'next/image';
import Link from "next/link"
import { notFound } from "next/navigation"
import { categories, getProductsByCategory } from "@/lib/products"

type Props = { params: Promise<{ category: string }> }

export default async function ProductPage({ params }: Props) {

    const { category } = await params

    const currentCategory = categories.find(
        (item) => item.slug === category
    )

    if (!currentCategory) {
        notFound()
    }

    const products = getProductsByCategory(
        currentCategory.slug
    )

    return (
        <main>
            <section className="catalog-header">

                <span className="eyebrow">
                    Browse
                </span>

                <h1>
                    {currentCategory.name}
                </h1>

                <p>
                    Explore our collection of{" "}
                    {currentCategory.name.toLowerCase()}.
                </p>

            </section>

            <section className="product-grid">

                {products.map((product) => (

                    <Link
                        key={product.id}
                        href={`/products/${category}/${product.slug}`}
                        className="product-card"
                    >

                        <div className="product-card-image">
                            <Image
                                width={300}
                                height={250}
                                src={product.image}
                                alt={product.name}
                            />
                        </div>

                        <div className="product-card-content">

                            <span className="eyebrow">
                                {product.category}
                            </span>

                            <h2>
                                {product.name}
                            </h2>

                            <strong>
                                ₦{product.price.toLocaleString()}
                            </strong>
                            
                            
                            <div className='my-2'>
                                <span>Stock: <em><strong>{product.stock}</strong> </em></span>
                                <h2>Features</h2>
                                <span className='mr-3'>{product.features[0]}</span>
                                <span className='mr-3'>{product.features[1]}</span>
                                <span className='mr-3'>{product.features[2]}</span>
                            </div>
                        </div>

                    </Link>

                ))}

            </section>

            <section className="product-bottom">

                <div>

                    <span className="eyebrow">
                        Simple. Fast. Reliable.
                    </span>

                    <h2>
                        Everything you need,
                        <br />
                        without the complexity.
                    </h2>

                </div>

                <p>
                    We make moving products and packages easier by
                    combining simple technology with dependable
                    logistics.
                </p>

            </section>
        </main>
    );
}