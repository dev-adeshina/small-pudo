"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { products } from "@/lib/products"

type CartItem = {
  productId: number
  quantity: number
}

export default function CartPage() {
  const [cart, setCart] = useState<CartItem[]>([])

  useEffect(() => {
    const stored = localStorage.getItem("cart")

    if (stored) {
      setCart(JSON.parse(stored))
    }
  }, [])

  const updateCart = (newCart: CartItem[]) => {
    setCart(newCart)
    localStorage.setItem("cart", JSON.stringify(newCart))
  }

  const increase = (productId: number) => {
    const newCart = cart.map((item) =>
      item.productId === productId
        ? {
            ...item,
            quantity: item.quantity + 1,
          }
        : item
    )

    updateCart(newCart)
  }

  const decrease = (productId: number) => {
    const newCart = cart
      .map((item) =>
        item.productId === productId
          ? {
              ...item,
              quantity: item.quantity - 1,
            }
          : item
      )
      .filter((item) => item.quantity > 0)

    updateCart(newCart)
  }

  const remove = (productId: number) => {
    updateCart(
      cart.filter(
        (item) => item.productId !== productId
      )
    )
  }

  const cartProducts = cart
    .map((item) => {
      const product = products.find(
        (product) => product.id === item.productId
      )

      return product
        ? {
            ...product,
            quantity: item.quantity,
          }
        : null
    })
    .filter(Boolean) as Array<
    (typeof products)[number] & {
      quantity: number
    }
  >

  const subtotal = cartProducts.reduce(
    (total, product) =>
      total + product.price * product.quantity,
    0
  )

  return (
    <main className="cart-page">
      <section className="page-heading">
        <span className="eyebrow">Your order</span>

        <h1>Your cart</h1>

        <p>
          Review your selected services before continuing.
        </p>
      </section>

      {cartProducts.length === 0 ? (
        <section className="empty-cart">
          <div className="empty-cart-icon">🛒</div>

          <h2>Your cart is empty</h2>

          <p>
            You haven't added anything to your cart yet.
          </p>

          <Link
            href="/"
            className="btn btn-primary"
          >
            Browse services
          </Link>
        </section>
      ) : (
        <section className="cart-layout">
          <div className="cart-items">
            {cartProducts.map((product) => (
              <article
                className="cart-item"
                key={product.id}
              >
                <img
                  src={product.image}
                  alt={product.name}
                />

                <div className="cart-item-info">
                  <span className="eyebrow">
                    {product.category}
                  </span>

                  <h2>{product.name}</h2>

                  <p>
                    ₦{product.price.toLocaleString()}
                  </p>
                </div>

                <div className="quantity">
                  <button
                    onClick={() =>
                      decrease(product.id)
                    }
                  >
                    −
                  </button>

                  <span>{product.quantity}</span>

                  <button
                    onClick={() =>
                      increase(product.id)
                    }
                  >
                    +
                  </button>
                </div>

                <div className="cart-item-total">
                  ₦
                  {(
                    product.price *
                    product.quantity
                  ).toLocaleString()}
                </div>

                <button
                  className="remove"
                  onClick={() => remove(product.id)}
                >
                  Remove
                </button>
              </article>
            ))}
          </div>

          <aside className="cart-summary">
            <h2>Order summary</h2>

            <div className="summary-row">
              <span>Subtotal</span>

              <strong>
                ₦{subtotal.toLocaleString()}
              </strong>
            </div>

            <div className="summary-row">
              <span>Delivery</span>

              <span>Calculated later</span>
            </div>

            <div className="summary-total">
              <span>Total</span>

              <strong>
                ₦{subtotal.toLocaleString()}
              </strong>
            </div>

            <button className="btn btn-primary checkout">
              Continue to checkout
            </button>
          </aside>
        </section>
      )}
    </main>
  )
}